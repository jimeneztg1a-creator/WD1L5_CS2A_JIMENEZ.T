'use strict';

const REG_FIELDS = [
  { id: 'fname', key: 'firstName', label: 'First name' },
  { id: 'lname', key: 'lastName', label: 'Last name' },
  { id: 'address', key: 'address', label: 'Address' },
  { id: 'uname', key: 'username', label: 'Username' },
  { id: 'email', key: 'email', label: 'Email address' },
  { id: 'pword', key: 'password', label: 'Password', trim: false },
];

const regForm = $('registerForm');
const regMessage = $('regMessage');

regForm.addEventListener('submit', (event) => {
  event.preventDefault();
  saveUserDetails();
});

function saveUserDetails() {
  const user = {};
  const missing = [];

  REG_FIELDS.forEach((field) => {
    const input = $(field.id);
    const value = field.trim === false ? input.value : input.value.trim();
    const isBlank = value === '';

    user[field.key] = value;
    setInvalid(input, isBlank);
    if (isBlank) missing.push(field.label);
  });

  if (missing.length > 0) {
    showMessage(regMessage, `Please complete: ${missing.join(', ')}.`, 'error');
    return;
  }

  // Let the browser check the email format
  const emailInput = $('email');
  if (!emailInput.checkValidity()) {
    setInvalid(emailInput, true);
    showMessage(regMessage, 'Please enter a valid email address.', 'error');
    return;
  }

  DataStore.set(STORAGE_KEYS.USER, user);
  showMessage(regMessage, 'Registration successful! Taking you to log in...', 'success');
  goTo('login.html', 900);
}
