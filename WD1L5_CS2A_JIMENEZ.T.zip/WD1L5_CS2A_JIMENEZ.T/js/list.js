'use strict';

// Only logged-in users can see this page
if (DataStore.get(STORAGE_KEYS.SESSION) === null) {
  window.location.href = 'login.html';
}

let items = DataStore.get(STORAGE_KEYS.ITEMS, []);

const itemForm = $('itemForm');
const nameInput = $('item_name');
const qtyInput = $('item_qty');
const listEl = $('groceryList');
const emptyEl = $('emptyMessage');
const summaryEl = $('summary');
const listMsg = $('listMessage');

// Events
itemForm.addEventListener('submit', (event) => {
  event.preventDefault();
  addItem();
});

$('clearBtn').addEventListener('click', clearList);
$('logoutBtn').addEventListener('click', logout);

// One listener handles every checkbox and remove button
listEl.addEventListener('click', (event) => {
  const row = event.target.closest('li');
  if (!row) return;

  const index = Number(row.dataset.index);

  if (event.target.matches('.remove')) {
    items.splice(index, 1);
    saveAndRender();
  } else if (event.target.matches("input[type='checkbox']")) {
    items[index].done = event.target.checked;
    saveAndRender();
  }
});

// Functions
function addItem() {
  const name = nameInput.value.trim();
  const qty = Number(qtyInput.value);

  const nameInvalid = name === '';
  const qtyInvalid = qtyInput.value === '' || qty < 1;

  setInvalid(nameInput, nameInvalid);
  setInvalid(qtyInput, qtyInvalid);

  if (nameInvalid || qtyInvalid) {
    showMessage(listMsg, 'Please enter an item name and a quantity of 1 or more.', 'error');
    return;
  }

  showMessage(listMsg, '');
  items.push({ name, qty, done: false });
  saveAndRender();

  itemForm.reset();
  nameInput.focus();
}

function clearList() {
  if (items.length === 0) return;
  if (!confirm('Remove all items from the list?')) return;

  items = [];
  saveAndRender();
}

// Ends the session only; the account is kept
function logout() {
  DataStore.remove(STORAGE_KEYS.SESSION);
  window.location.href = 'login.html';
}

function saveAndRender() {
  DataStore.set(STORAGE_KEYS.ITEMS, items);
  renderList();
}

function createRow(item, index) {
  const li = document.createElement('li');
  li.className = 'grocery-item';
  li.classList.toggle('done', item.done);
  li.dataset.index = index;

  const label = document.createElement('label');
  label.className = 'check';

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = item.done;

  const name = document.createElement('span');
  name.className = 'name';
  name.textContent = item.name;

  label.append(checkbox, name);

  const leader = document.createElement('span');
  leader.className = 'leader';
  leader.setAttribute('aria-hidden', 'true');

  const qty = document.createElement('span');
  qty.className = 'qty';
  qty.textContent = `Qty: ${item.qty}`;

  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'remove';
  remove.textContent = '\u00D7';
  remove.setAttribute('aria-label', `Remove ${item.name}`);

  li.append(label, leader, qty, remove);
  return li;
}

function renderList() {
  listEl.innerHTML = '';
  items.forEach((item, index) => listEl.appendChild(createRow(item, index)));

  const doneCount = items.filter((item) => item.done).length;
  summaryEl.textContent =
    items.length === 0 ? '' : `${doneCount} of ${items.length} in the basket`;
  emptyEl.hidden = items.length > 0;
}

renderList();
