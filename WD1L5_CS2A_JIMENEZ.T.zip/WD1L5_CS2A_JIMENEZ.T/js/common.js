'use strict';

const STORAGE_KEYS = {
  USER: 'userRecord',
  SESSION: 'loggedInUser',
  ITEMS: 'groceryItems',
};

const DataStore = {
  // Read a value, or return the fallback
  get(key, fallback = null) {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (error) {
      return fallback;
    }
  },

  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },

  remove(key) {
    localStorage.removeItem(key);
  },
};

// Shortcut for getElementById
const $ = (id) => document.getElementById(id);

// Show a message. type: 'error', 'success', or '' to clear
function showMessage(element, text, type = '') {
  element.textContent = text;
  element.className = `message ${type}`.trim();
}

// Mark an input as valid or invalid
function setInvalid(input, isInvalid) {
  input.classList.toggle('invalid', isInvalid);
  input.setAttribute('aria-invalid', String(isInvalid));
}

// Go to another page after an optional delay
function goTo(page, delay = 0) {
  setTimeout(() => {
    window.location.href = page;
  }, delay);
}
