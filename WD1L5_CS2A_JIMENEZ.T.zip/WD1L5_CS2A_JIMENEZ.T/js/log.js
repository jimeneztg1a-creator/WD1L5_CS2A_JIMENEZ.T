'use strict';

const loginForm = $('loginForm');
const loginMessage = $('loginMessage');

loginForm.addEventListener('submit', (event) => {
  event.preventDefault();
  loginUser();
});

function loginUser() {
  const savedUser = DataStore.get(STORAGE_KEYS.USER);

  if (savedUser === null) {
    showMessage(loginMessage, 'No user record found. Kindly register first.', 'error');
    return;
  }

  const username = $('login_uname').value.trim();
  const password = $('login_pword').value;

  if (username !== savedUser.username || password !== savedUser.password) {
    showMessage(loginMessage, 'Invalid user credentials!', 'error');
    return;
  }

  // Remember the user so list.html lets them in
  DataStore.set(STORAGE_KEYS.SESSION, savedUser.username);

  showMessage(
    loginMessage,
    `Welcome ${savedUser.firstName}! You may now add an item.`,
    'success'
  );
  goTo('list.html', 900);
}
